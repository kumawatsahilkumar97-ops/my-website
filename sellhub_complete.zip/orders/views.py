from collections import defaultdict

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from products.models import Product, ProductVariety
from .forms import AddressForm
from .models import Cart, CartItem, Address, Order, OrderItem


def _get_or_create_cart(user):
    cart, _ = Cart.objects.get_or_create(user=user)
    return cart


@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    variety_id = request.POST.get('variety_id')
    quantity = int(request.POST.get('quantity', 1) or 1)
    variety = None
    if variety_id:
        variety = get_object_or_404(ProductVariety, pk=variety_id, product=product)
        if variety.stock_quantity < quantity:
            messages.error(request, f'Only {variety.stock_quantity} left in stock for "{variety.name}".')
            return redirect(product.get_absolute_url())

    cart = _get_or_create_cart(request.user)
    item, created = CartItem.objects.get_or_create(
        cart=cart, product=product, variety=variety,
        defaults={'quantity': quantity},
    )
    if not created:
        item.quantity += quantity
        item.save()

    messages.success(request, f'Added "{product.name}" to your cart.')
    return redirect('orders:cart_view')


@login_required
def cart_view(request):
    cart = _get_or_create_cart(request.user)
    items = cart.items.select_related('product', 'variety', 'product__seller')
    return render(request, 'orders/cart.html', {'cart': cart, 'items': items})


@login_required
@require_POST
def update_cart_item(request, item_id):
    cart = _get_or_create_cart(request.user)
    item = get_object_or_404(CartItem, pk=item_id, cart=cart)
    action = request.POST.get('action')
    if action == 'remove':
        item.delete()
        messages.success(request, 'Item removed from cart.')
    else:
        quantity = int(request.POST.get('quantity', item.quantity) or 1)
        item.quantity = max(1, quantity)
        item.save()
    return redirect('orders:cart_view')


@login_required
def address_list(request):
    addresses = request.user.addresses.all()
    if request.method == 'POST':
        form = AddressForm(request.POST)
        if form.is_valid():
            addr = form.save(commit=False)
            addr.user = request.user
            addr.save()
            messages.success(request, 'Address saved.')
            return redirect('orders:address_list')
    else:
        form = AddressForm()
    return render(request, 'orders/address_list.html', {'addresses': addresses, 'form': form})


@login_required
def checkout(request):
    cart = _get_or_create_cart(request.user)
    items = list(cart.items.select_related('product', 'variety', 'product__seller'))
    if not items:
        messages.info(request, 'Your cart is empty.')
        return redirect('orders:cart_view')

    addresses = request.user.addresses.all()

    if request.method == 'POST':
        address_id = request.POST.get('address_id')
        address = get_object_or_404(Address, pk=address_id, user=request.user)

        # Group cart items by seller — one Order per seller, since each is an
        # independent small shop fulfilling their own items.
        items_by_seller = defaultdict(list)
        for item in items:
            if item.variety and item.variety.stock_quantity < item.quantity:
                messages.error(request, f'"{item.product.name}" ({item.variety.name}) only has {item.variety.stock_quantity} left.')
                return redirect('orders:cart_view')
            items_by_seller[item.product.seller].append(item)

        created_orders = []
        with transaction.atomic():
            for seller, seller_items in items_by_seller.items():
                total = sum((item.line_total for item in seller_items), 0)
                order = Order.objects.create(
                    customer=request.user, seller=seller, shipping_address=address,
                    total_amount=total,
                )
                for item in seller_items:
                    OrderItem.objects.create(
                        order=order, product=item.product, variety=item.variety,
                        product_name=item.product.name,
                        variety_name=item.variety.name if item.variety else '',
                        unit_price=item.unit_price, quantity=item.quantity,
                    )
                    if item.variety:
                        item.variety.stock_quantity -= item.quantity
                        item.variety.save(update_fields=['stock_quantity'])
                created_orders.append(order)
            cart.items.all().delete()

        messages.success(request, f'{len(created_orders)} order(s) placed successfully!')
        return redirect('orders:order_history')

    return render(request, 'orders/checkout.html', {
        'cart': cart, 'items': items, 'addresses': addresses,
    })


@login_required
def order_history(request):
    orders = request.user.orders.all().prefetch_related('items').select_related('seller')
    return render(request, 'orders/order_history.html', {'orders': orders})


@login_required
def order_detail(request, order_number):
    order = get_object_or_404(Order, order_number=order_number)
    is_customer = order.customer == request.user
    is_seller_owner = getattr(request.user, 'seller_profile', None) == order.seller
    if not (is_customer or is_seller_owner or getattr(request.user, 'is_admin_role', False)):
        raise PermissionDenied
    return render(request, 'orders/order_detail.html', {'order': order, 'is_seller_owner': is_seller_owner})


@login_required
def seller_orders(request):
    """Orders placed with the logged-in seller's shop."""
    profile = getattr(request.user, 'seller_profile', None)
    if profile is None:
        raise PermissionDenied
    orders = profile.orders.all().prefetch_related('items').select_related('customer')
    return render(request, 'orders/seller_orders.html', {'orders': orders})


@login_required
@require_POST
def update_order_status(request, order_number):
    order = get_object_or_404(Order, order_number=order_number)
    profile = getattr(request.user, 'seller_profile', None)
    if profile != order.seller:
        raise PermissionDenied
    new_status = request.POST.get('status')
    if new_status in dict(Order.Status.choices):
        order.status = new_status
        order.save(update_fields=['status'])
        messages.success(request, f'Order {order.order_number} marked as {order.get_status_display()}.')
    return redirect('orders:seller_orders')
