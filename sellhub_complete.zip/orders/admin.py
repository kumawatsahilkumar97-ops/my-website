from django.contrib import admin
from .models import Address, Cart, CartItem, Order, OrderItem


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'user', 'city', 'is_default')
    search_fields = ('full_name', 'user__username', 'city')


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('product', 'variety', 'product_name', 'variety_name', 'unit_price', 'quantity')


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'customer', 'seller', 'status', 'total_amount', 'created_at')
    list_filter = ('status',)
    search_fields = ('order_number', 'customer__username', 'seller__shop_name')
    inlines = [OrderItemInline]
    readonly_fields = ('order_number',)


admin.site.register(Cart)
admin.site.register(CartItem)
