from django.urls import path

from . import views

app_name = 'orders'

urlpatterns = [
    path('cart/', views.cart_view, name='cart_view'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/item/<int:item_id>/update/', views.update_cart_item, name='update_cart_item'),

    path('addresses/', views.address_list, name='address_list'),
    path('checkout/', views.checkout, name='checkout'),

    path('my-orders/', views.order_history, name='order_history'),
    path('order/<str:order_number>/', views.order_detail, name='order_detail'),

    path('seller/orders/', views.seller_orders, name='seller_orders'),
    path('seller/orders/<str:order_number>/status/', views.update_order_status, name='update_order_status'),
]
