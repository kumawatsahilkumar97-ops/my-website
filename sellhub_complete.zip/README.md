# SellHub — Marketplace Platform for Small Sellers

A Django-based marketplace connecting customers with small, independent
sellers. This is **Step 1: Project Setup** — project scaffolding, MySQL
config, custom user model with roles, and authentication.

## Tech Stack
- Django 5.x
- MySQL (via `mysqlclient`)
- Django templates + Bootstrap 5 (server-rendered UI)
- Pillow (for profile picture / image uploads)

## What's included in Step 1
- Custom `User` model (`accounts.User`) with roles: `CUSTOMER`, `SELLER`, `ADMIN`
- Seller accounts start as **unverified** (`is_verified=False`) until an
  admin approves them — ties into Step 9 (Admin & Trust)
- Signup (customer / seller), login, logout
- Role-based dashboard redirect after login
- Bootstrap-styled templates: home, login, signup (x2), dashboards (x3), profile
- Django admin registered for the User model

## Local Setup

### 1. Clone & create a virtual environment
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```
> `mysqlclient` requires MySQL dev headers on your system.
> - Ubuntu/Debian: `sudo apt-get install default-libmysqlclient-dev build-essential pkg-config`
> - macOS: `brew install mysql-client pkg-config`
> - Windows: use the prebuilt wheel (usually installs fine via pip).

### 3. Configure environment variables
```bash
cp .env.example .env
```
Edit `.env` and set your MySQL credentials (`DB_NAME`, `DB_USER`, `DB_PASSWORD`, etc.)
and a real `DJANGO_SECRET_KEY`.

**Don't have MySQL running yet?** Set `DJANGO_USE_SQLITE=True` in `.env` to
use SQLite instead for local development — no other changes needed.

### 4. Create the MySQL database (skip if using SQLite)
```sql
CREATE DATABASE sellhub_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Run migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create a superuser (for Django admin / platform admin)
```bash
python manage.py createsuperuser
```

### 7. Run the dev server
```bash
python manage.py runserver
```
Visit `http://127.0.0.1:8000/`

## URLs
| URL | Description |
|---|---|
| `/` | Home / landing page |
| `/login/` | Login |
| `/signup/customer/` | Customer registration |
| `/signup/seller/` | Seller registration (starts unverified) |
| `/dashboard/` | Redirects to the right dashboard based on role |
| `/profile/` | Edit profile |
| `/admin/` | Django admin (superuser only) |

## Project Structure
```
sellhub/
├── sellhub/          # Project settings, root urls, wsgi/asgi
├── accounts/         # Custom User model, auth views, forms
├── templates/         # Bootstrap-based HTML templates
│   ├── base.html
│   └── accounts/
├── static/            # Static assets (CSS/JS/images)
├── requirements.txt
├── .env.example
└── manage.py
```

## Step 2 — Seller System
- `sellers.SellerProfile` model: shop name/slug, description, logo/banner,
  village/locality, city/state/pincode, lat/long, business category, GST
  number, ID proof upload
- Seller dashboard → **Set Up Shop** / **Edit Shop** button
- `/shop/setup/` — create/edit shop profile (any edit re-queues for review)
- `/shops/` — public list of live (approved + active) shops
- `/shop/<slug>/` — public storefront page; owner/admin can preview even
  before it's live
- Django admin: **Approve selected sellers** / **Reject selected sellers**
  bulk actions on `SellerProfile` — approving flips both the shop's
  `verification_status` and the seller's `User.is_verified` flag together

### New URLs
| URL | Description |
|---|---|
| `/shop/setup/` | Seller-only: create/edit shop profile |
| `/shops/` | Public: browse verified shops |
| `/shop/<slug>/` | Public: shop storefront page |

## Step 3 — Product System
- `products.Category` (supports subcategories via self-referencing parent)
- `products.Product` — belongs to a seller, has a category, unit
  (piece/kg/gram/litre/dozen/pack/meter), base price, `is_customizable` flag
  (feeds Step 7), and `is_active` (hide without deleting)
- `products.ProductVariety` — sellable options per product (e.g. sizes,
  weights, colors), each with its own price and stock quantity
- `products.ProductImage` — multiple images per product, one marked primary
- Seller-only CRUD at `/my-products/` (list, add, edit, delete) using
  Django formsets so varieties + images are managed on the same page as
  the product
- Public product page at `/shop/<shop_slug>/product/<product_slug>/`
  (hidden unless the shop is live and the product is active, unless
  viewed by the owner)
- Shop page now lists the seller's live products
- `/categories/` — public category browse page

### New URLs
| URL | Description |
|---|---|
| `/my-products/` | Seller-only: manage products |
| `/my-products/add/` | Seller-only: add product |
| `/my-products/<id>/edit/` | Seller-only: edit product |
| `/my-products/<id>/delete/` | Seller-only: delete product |
| `/categories/` | Public: browse categories |
| `/shop/<shop_slug>/product/<product_slug>/` | Public: product detail |

## Step 4 — Batch & Traceability
- `traceability.Batch` (auto-generated batch code, origin, raw material
  source, produced date/quantity) and `traceability.ProcessingStep`
  (ordered journey stages, each with title/description/location/date/image)
- Seller-only batch management under each product; public "trace this
  batch" timeline page linked from the product detail page

## Step 5 — Customer Marketplace
- `/search/` — full search & filter/sort page: text query, category, city,
  price range, sort by newest/price

## Step 6 — Shopping System
- `Address`, `Cart`, `CartItem`, `Order`, `OrderItem` models
- Add to cart (with stock check), cart page, checkout that **automatically
  splits into one Order per seller** (since each seller is an independent
  small shop), order history, and seller-side order status management
- Verified: stock decrements correctly on checkout

## Step 7 — Customization
- `CustomizationRequest` + `CustomizationQuotation` — a customer requests a
  custom version of a specific product; the seller who owns that product
  sends a price + turnaround quote; customer accepts/cancels

## Step 8 — Demand System
- `DemandRequest` + `DemandQuotation` — an open "Request a Product" board;
  customer posts what they need (not tied to any seller), any seller can
  submit a quote, customer accepts one (auto-rejects the rest, closes the
  request)

## Step 9 — Admin & Trust
- `Review` (tied to a delivered order, so only verified purchasers can
  review) and `Report` (fraud/quality/etc., filed against a seller or
  product) models
- Public seller review pages, "Report this shop" link
- `/admin-panel/overview/` — platform-wide stats dashboard (customers,
  sellers, pending verifications, orders, revenue, open reports) plus
  quick queues for pending sellers and open reports

## Step 10 — Security + Deployment
- WhiteNoise configured for compressed, cache-busted static file serving
  in production
- Production-only security hardening (auto-enabled when `DJANGO_DEBUG=False`):
  HTTPS redirect, secure cookies, HSTS, content-type sniffing protection,
  clickjacking protection, `CSRF_TRUSTED_ORIGINS` from env
- Upload size limits (10MB) to prevent abuse
- Console logging configured for platform log aggregators
- `Procfile` for Railway/Heroku-style platforms (`gunicorn` + release-phase
  migrate & collectstatic)
- Verified: `manage.py check --deploy` and `collectstatic` both run clean

### New URLs (Steps 4–9)
| URL | Description |
|---|---|
| `/my-products/<id>/batches/` | Seller-only: manage batches |
| `/product/<id>/trace/<batch_id>/` | Public: batch traceability timeline |
| `/search/` | Public: marketplace search & filters |
| `/cart/`, `/checkout/`, `/my-orders/` | Customer shopping flow |
| `/seller/orders/` | Seller order management |
| `/customize/product/<id>/` | Customer: request customization |
| `/customize/seller/requests/` | Seller: quote customization requests |
| `/demand/browse/`, `/demand/new/` | Public demand board / post a request |
| `/order/<order_number>/review/` | Leave a review (post-delivery) |
| `/report/` | File a trust & safety report |
| `/admin-panel/overview/` | Admin platform dashboard |

## Roadmap
1. ✅ Project Setup — Django + MySQL + auth + roles
2. ✅ Seller System — shop profile, village/location, verification
3. ✅ Product System — categories, products, varieties, images
4. ✅ Batch & Traceability — batch, origin, processing journey
5. ✅ Customer Marketplace — search, filters, product details
6. ✅ Shopping System — cart, address, checkout, orders
7. ✅ Customization — custom product requests + seller quotations
8. ✅ Demand System — "Request a Product" + seller quotations
9. ✅ Admin & Trust — admin dashboard, verification, reviews, reports
10. ✅ Security + Deployment — security hardening, static files, deployment

## Deploying to production
1. Provision a MySQL database and a host (Railway, Render, a VPS, etc.)
2. Set all the environment variables from `.env.example` — especially a
   real `DJANGO_SECRET_KEY` (generate with
   `python -c "import secrets; print(secrets.token_urlsafe(50))"`),
   `DJANGO_DEBUG=False`, your real `DJANGO_ALLOWED_HOSTS`, and
   `DJANGO_CSRF_TRUSTED_ORIGINS`
3. `pip install -r requirements.txt`
4. `python manage.py migrate`
5. `python manage.py collectstatic --noinput`
6. Run with `gunicorn sellhub.wsgi:application` behind your platform's
   HTTPS termination (the `Procfile` handles this automatically on
   Railway/Heroku-style platforms)
7. Create your admin superuser: `python manage.py createsuperuser`

3. Product System — categories, products, varieties, images
4. Batch & Traceability — batch, origin, processing journey
5. Customer Marketplace — search, filters, product details
6. Shopping System — cart, address, checkout, orders
7. Customization — custom product requests + seller quotations
8. Demand System — "Request a Product" + seller quotations
9. Admin & Trust — admin dashboard, verification, reviews, reports
10. Security + Deployment — security hardening, responsive UI, deployment
