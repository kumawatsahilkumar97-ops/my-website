from django.contrib import admin
from .models import Batch, ProcessingStep


class ProcessingStepInline(admin.TabularInline):
    model = ProcessingStep
    extra = 1


@admin.register(Batch)
class BatchAdmin(admin.ModelAdmin):
    list_display = ('batch_code', 'product', 'origin_place', 'produced_date', 'quantity_produced', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('batch_code', 'product__name', 'origin_place')
    inlines = [ProcessingStepInline]
