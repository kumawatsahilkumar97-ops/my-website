from django.db import models
from django.utils.text import slugify


class Batch(models.Model):
    """
    A production/stock batch for a product (or specific variety). Lets a
    seller tell the story of where a batch came from and how it was made —
    especially useful for handmade goods, farm produce, and food items.
    """
    product = models.ForeignKey(
        'products.Product', on_delete=models.CASCADE, related_name='batches',
    )
    variety = models.ForeignKey(
        'products.ProductVariety', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='batches',
        help_text='Optional: tie this batch to a specific variety.',
    )
    batch_code = models.CharField(
        max_length=50, blank=True,
        help_text='Auto-generated if left blank, e.g. RH-20260812-0001',
    )

    origin_place = models.CharField(
        max_length=150,
        help_text='Village/town/region this batch originated from.',
    )
    raw_material_source = models.CharField(
        max_length=255, blank=True,
        help_text='e.g. "Locally sourced clay", "Cotton from local farms"',
    )
    produced_date = models.DateField()
    quantity_produced = models.PositiveIntegerField()

    is_active = models.BooleanField(
        default=True, help_text='Uncheck once this batch is fully sold out or retired.',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-produced_date']

    def __str__(self):
        return self.batch_code or f'Batch for {self.product.name}'

    def save(self, *args, **kwargs):
        if not self.batch_code:
            from django.utils import timezone
            seller_prefix = slugify(self.product.seller.shop_name)[:3].upper()
            date_part = timezone.now().strftime('%Y%m%d')
            count = Batch.objects.filter(product__seller=self.product.seller).count() + 1
            self.batch_code = f'{seller_prefix}-{date_part}-{count:04d}'
        super().save(*args, **kwargs)


class ProcessingStep(models.Model):
    """
    One stage in a batch's journey from raw material to finished product —
    e.g. "Harvested" -> "Cleaned" -> "Dried" -> "Packaged". Ordered by
    `sequence` so the traceability timeline renders in the right order.
    """
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, related_name='processing_steps')
    sequence = models.PositiveIntegerField(default=1)
    title = models.CharField(max_length=150, help_text='e.g. "Harvested", "Hand-woven", "Packaged"')
    description = models.TextField(blank=True)
    location = models.CharField(max_length=150, blank=True)
    step_date = models.DateField(null=True, blank=True)
    image = models.ImageField(upload_to='processing_steps/', blank=True, null=True)

    class Meta:
        ordering = ['sequence']

    def __str__(self):
        return f'{self.batch.batch_code} — Step {self.sequence}: {self.title}'
