from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404

from products.models import Product
from .forms import BatchForm, ProcessingStepFormSet
from .models import Batch


def _own_product(user, product_id):
    product = get_object_or_404(Product, pk=product_id)
    if not user.is_authenticated or getattr(user, 'seller_profile', None) != product.seller:
        raise PermissionDenied('You can only manage batches for your own products.')
    return product


@login_required
def batch_list(request, product_id):
    product = _own_product(request.user, product_id)
    batches = product.batches.all().prefetch_related('processing_steps')
    return render(request, 'traceability/batch_list.html', {'product': product, 'batches': batches})


@login_required
def batch_create(request, product_id):
    product = _own_product(request.user, product_id)

    if request.method == 'POST':
        form = BatchForm(request.POST, product=product)
        if form.is_valid():
            batch = form.save(commit=False)
            batch.product = product
            batch.save()
            step_formset = ProcessingStepFormSet(request.POST, request.FILES, instance=batch)
            if step_formset.is_valid():
                step_formset.save()
                messages.success(request, f'Batch "{batch.batch_code}" created.')
                return redirect('traceability:batch_list', product_id=product.id)
        else:
            step_formset = ProcessingStepFormSet(request.POST, request.FILES)
    else:
        form = BatchForm(product=product)
        step_formset = ProcessingStepFormSet()

    return render(request, 'traceability/batch_form.html', {
        'form': form, 'step_formset': step_formset, 'product': product, 'is_new': True,
    })


@login_required
def batch_edit(request, product_id, pk):
    product = _own_product(request.user, product_id)
    batch = get_object_or_404(Batch, pk=pk, product=product)

    if request.method == 'POST':
        form = BatchForm(request.POST, instance=batch, product=product)
        step_formset = ProcessingStepFormSet(request.POST, request.FILES, instance=batch)
        if form.is_valid() and step_formset.is_valid():
            form.save()
            step_formset.save()
            messages.success(request, f'Batch "{batch.batch_code}" updated.')
            return redirect('traceability:batch_list', product_id=product.id)
    else:
        form = BatchForm(instance=batch, product=product)
        step_formset = ProcessingStepFormSet(instance=batch)

    return render(request, 'traceability/batch_form.html', {
        'form': form, 'step_formset': step_formset, 'product': product, 'is_new': False, 'batch': batch,
    })


def batch_trace_public(request, product_id, pk):
    """Public traceability timeline for a batch — the 'origin story' customers see."""
    product = get_object_or_404(Product, pk=product_id)
    batch = get_object_or_404(Batch, pk=pk, product=product, is_active=True)
    steps = batch.processing_steps.all()
    return render(request, 'traceability/batch_trace_public.html', {
        'product': product, 'batch': batch, 'steps': steps,
    })
