from django import forms
from django.forms import inlineformset_factory

from .models import Batch, ProcessingStep


def _bootstrapify(form):
    for field in form.fields.values():
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = 'form-check-input'
        else:
            existing = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = (existing + ' form-control').strip()
    return form


class BatchForm(forms.ModelForm):
    class Meta:
        model = Batch
        fields = [
            'variety', 'origin_place', 'raw_material_source',
            'produced_date', 'quantity_produced', 'is_active',
        ]
        widgets = {'produced_date': forms.DateInput(attrs={'type': 'date'})}

    def __init__(self, *args, product=None, **kwargs):
        super().__init__(*args, **kwargs)
        if product is not None:
            self.fields['variety'].queryset = product.varieties.all()
        _bootstrapify(self)


class ProcessingStepForm(forms.ModelForm):
    class Meta:
        model = ProcessingStep
        fields = ['sequence', 'title', 'description', 'location', 'step_date', 'image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 2}),
            'step_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


ProcessingStepFormSet = inlineformset_factory(
    Batch, ProcessingStep,
    form=ProcessingStepForm,
    extra=2, can_delete=True,
)
