from django.urls import path

from . import views

app_name = 'traceability'

urlpatterns = [
    path('my-products/<int:product_id>/batches/', views.batch_list, name='batch_list'),
    path('my-products/<int:product_id>/batches/add/', views.batch_create, name='batch_create'),
    path('my-products/<int:product_id>/batches/<int:pk>/edit/', views.batch_edit, name='batch_edit'),
    path('product/<int:product_id>/trace/<int:pk>/', views.batch_trace_public, name='batch_trace_public'),
]
