from django import forms

from .models import SellerProfile


class SellerProfileForm(forms.ModelForm):
    class Meta:
        model = SellerProfile
        fields = [
            'shop_name', 'shop_description', 'shop_logo', 'shop_banner',
            'business_category', 'village_or_locality', 'address_line',
            'city', 'state', 'pincode', 'latitude', 'longitude',
            'gst_number', 'id_proof_document',
        ]
        widgets = {
            'shop_description': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if isinstance(field.widget, (forms.CheckboxInput,)):
                continue
            existing = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = (existing + ' form-control').strip()
