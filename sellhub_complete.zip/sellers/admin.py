from django.contrib import admin
from django.utils import timezone

from .models import SellerProfile


@admin.register(SellerProfile)
class SellerProfileAdmin(admin.ModelAdmin):
    list_display = (
        'shop_name', 'user', 'city', 'state',
        'verification_status', 'is_active', 'created_at',
    )
    list_filter = ('verification_status', 'is_active', 'state', 'business_category')
    search_fields = ('shop_name', 'user__username', 'user__email', 'city', 'village_or_locality')
    readonly_fields = ('shop_slug', 'created_at', 'updated_at', 'verified_at', 'verified_by')
    actions = ['approve_sellers', 'reject_sellers']

    @admin.action(description='Approve selected sellers (marks shop + user as verified)')
    def approve_sellers(self, request, queryset):
        updated = 0
        for profile in queryset:
            profile.verification_status = SellerProfile.VerificationStatus.APPROVED
            profile.verified_at = timezone.now()
            profile.verified_by = request.user
            profile.save()
            profile.user.is_verified = True
            profile.user.save(update_fields=['is_verified'])
            updated += 1
        self.message_user(request, f'{updated} seller(s) approved and gone live.')

    @admin.action(description='Reject selected sellers')
    def reject_sellers(self, request, queryset):
        updated = queryset.update(
            verification_status=SellerProfile.VerificationStatus.REJECTED,
            verified_at=None,
            verified_by=None,
        )
        self.message_user(request, f'{updated} seller(s) rejected.')
