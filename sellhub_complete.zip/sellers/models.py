from django.conf import settings
from django.db import models
from django.urls import reverse


class SellerProfile(models.Model):
    """
    Extended shop/business profile for a User with role=SELLER.
    Kept separate from the User model so Step 1 (auth) stays lean and this
    can grow independently (shop branding, location, verification docs, etc).
    """

    class VerificationStatus(models.TextChoices):
        PENDING = 'PENDING', 'Pending Review'
        APPROVED = 'APPROVED', 'Approved'
        REJECTED = 'REJECTED', 'Rejected'

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='seller_profile',
        limit_choices_to={'role': 'SELLER'},
    )

    # --- Shop identity ---
    shop_name = models.CharField(max_length=150)
    shop_slug = models.SlugField(max_length=160, unique=True, blank=True)
    shop_description = models.TextField(blank=True)
    shop_logo = models.ImageField(upload_to='shop_logos/', blank=True, null=True)
    shop_banner = models.ImageField(upload_to='shop_banners/', blank=True, null=True)

    # --- Location ---
    # "village" kept as its own field since many small sellers operate from
    # villages/small towns rather than a formal registered business address,
    # but this works equally well for urban small sellers (leave blank).
    village_or_locality = models.CharField(
        max_length=150, blank=True,
        help_text='Village, locality, or neighbourhood the shop operates from.',
    )
    address_line = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    # --- Business details ---
    business_category = models.CharField(
        max_length=100, blank=True,
        help_text='e.g. Handicrafts, Groceries, Textiles, Farm Produce, etc.',
    )
    gst_number = models.CharField(max_length=20, blank=True, null=True)
    id_proof_document = models.FileField(
        upload_to='seller_verification_docs/', blank=True, null=True,
        help_text='Aadhaar / shop license / any ID proof for verification.',
    )

    # --- Verification (feeds into Step 9 admin trust workflow) ---
    verification_status = models.CharField(
        max_length=10,
        choices=VerificationStatus.choices,
        default=VerificationStatus.PENDING,
    )
    verification_notes = models.TextField(
        blank=True, help_text='Admin notes on approval/rejection.'
    )
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='sellers_verified',
    )

    is_active = models.BooleanField(
        default=True,
        help_text='Seller can temporarily deactivate their shop (e.g. on vacation).',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.shop_name} ({self.get_verification_status_display()})'

    def save(self, *args, **kwargs):
        if not self.shop_slug:
            from django.utils.text import slugify
            base_slug = slugify(self.shop_name)
            slug = base_slug
            counter = 1
            while SellerProfile.objects.filter(shop_slug=slug).exclude(pk=self.pk).exists():
                slug = f'{base_slug}-{counter}'
                counter += 1
            self.shop_slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('sellers:shop_detail', kwargs={'slug': self.shop_slug})

    @property
    def is_live(self):
        """Shop is visible to customers only if verified, active, and user.is_verified."""
        return (
            self.is_active
            and self.verification_status == self.VerificationStatus.APPROVED
            and self.user.is_verified
        )
