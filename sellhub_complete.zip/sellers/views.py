from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404

from .forms import SellerProfileForm
from .models import SellerProfile


def _require_seller(user):
    if not user.is_authenticated or not user.is_seller:
        raise PermissionDenied('Only sellers can access this page.')


@login_required
def shop_setup(request):
    """Create or edit the logged-in seller's shop profile."""
    _require_seller(request.user)

    profile = SellerProfile.objects.filter(user=request.user).first()
    is_new = profile is None

    if request.method == 'POST':
        form = SellerProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            seller_profile = form.save(commit=False)
            seller_profile.user = request.user
            if not is_new:
                # Any edit to a live profile sends it back for re-review,
                # so admins can confirm changes are still trustworthy.
                seller_profile.verification_status = SellerProfile.VerificationStatus.PENDING
                seller_profile.verified_at = None
                seller_profile.verified_by = None
            seller_profile.save()
            messages.success(
                request,
                'Shop profile saved! It will be (re-)reviewed by an admin before going live.'
                if is_new else
                'Shop profile updated. Changes are pending re-verification.',
            )
            return redirect('sellers:shop_setup')
    else:
        form = SellerProfileForm(instance=profile)

    return render(request, 'sellers/shop_setup.html', {
        'form': form,
        'profile': profile,
        'is_new': is_new,
    })


def shop_detail(request, slug):
    """Public storefront page for a seller's shop (visible only if live, unless owner/staff)."""
    profile = get_object_or_404(SellerProfile, shop_slug=slug)

    is_owner = request.user.is_authenticated and request.user == profile.user
    is_staff_viewer = request.user.is_authenticated and getattr(request.user, 'is_admin_role', False)

    if not profile.is_live and not (is_owner or is_staff_viewer):
        raise PermissionDenied('This shop is not currently available.')

    return render(request, 'sellers/shop_detail.html', {
        'profile': profile,
        'is_owner': is_owner,
    })


def shop_list(request):
    """Browse all verified/live shops (basic version — search/filter comes in Step 5)."""
    shops = SellerProfile.objects.filter(
        is_active=True,
        verification_status=SellerProfile.VerificationStatus.APPROVED,
        user__is_verified=True,
    )
    return render(request, 'sellers/shop_list.html', {'shops': shops})
