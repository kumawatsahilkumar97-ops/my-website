from django.urls import path

from . import views

app_name = 'sellers'

urlpatterns = [
    path('shop/setup/', views.shop_setup, name='shop_setup'),
    path('shops/', views.shop_list, name='shop_list'),
    path('shop/<slug:slug>/', views.shop_detail, name='shop_detail'),
]
