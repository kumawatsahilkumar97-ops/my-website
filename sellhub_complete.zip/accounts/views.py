from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import View

from .forms import CustomerSignUpForm, SellerSignUpForm, ProfileUpdateForm, apply_bootstrap
from .models import User


def home(request):
    """Public landing page."""
    return render(request, 'accounts/home.html')


class CustomerSignUpView(View):
    template_name = 'accounts/signup_customer.html'

    def get(self, request):
        form = CustomerSignUpForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = CustomerSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome! Your account has been created.')
            return redirect('accounts:dashboard_redirect')
        return render(request, self.template_name, {'form': form})


class SellerSignUpView(View):
    template_name = 'accounts/signup_seller.html'

    def get(self, request):
        form = SellerSignUpForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = SellerSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.info(
                request,
                'Your seller account was created and is pending verification. '
                'You can set up your shop now, but it will only go live after admin approval.',
            )
            return redirect('accounts:dashboard_redirect')
        return render(request, self.template_name, {'form': form})


class RoleAwareLoginView(LoginView):
    template_name = 'accounts/login.html'
    redirect_authenticated_user = True

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        return apply_bootstrap(form)


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out.')
    return redirect('accounts:login')


@login_required
def dashboard_redirect(request):
    """Sends the logged-in user to the right dashboard based on their role."""
    user = request.user
    if user.is_superuser or user.role == User.Role.ADMIN:
        return redirect('accounts:admin_dashboard')
    if user.role == User.Role.SELLER:
        return redirect('accounts:seller_dashboard')
    return redirect('accounts:customer_dashboard')


@login_required
def customer_dashboard(request):
    return render(request, 'accounts/customer_dashboard.html')


@login_required
def seller_dashboard(request):
    if not request.user.is_seller:
        messages.error(request, 'Access restricted to sellers only.')
        return redirect('accounts:dashboard_redirect')
    return render(request, 'accounts/seller_dashboard.html')


@login_required
def admin_dashboard(request):
    if not request.user.is_admin_role:
        messages.error(request, 'Access restricted to admins only.')
        return redirect('accounts:dashboard_redirect')
    return render(request, 'accounts/admin_dashboard.html')


@login_required
def profile_view(request):
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('accounts:profile')
    else:
        form = ProfileUpdateForm(instance=request.user)
    return render(request, 'accounts/profile.html', {'form': form})
