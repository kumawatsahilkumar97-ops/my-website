from django.urls import path
from django.contrib.auth.views import LogoutView

from . import views

app_name = 'accounts'

urlpatterns = [
    path('', views.home, name='home'),

    # Auth
    path('signup/customer/', views.CustomerSignUpView.as_view(), name='signup_customer'),
    path('signup/seller/', views.SellerSignUpView.as_view(), name='signup_seller'),
    path('login/', views.RoleAwareLoginView.as_view(), name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Dashboards
    path('dashboard/', views.dashboard_redirect, name='dashboard_redirect'),
    path('dashboard/customer/', views.customer_dashboard, name='customer_dashboard'),
    path('dashboard/seller/', views.seller_dashboard, name='seller_dashboard'),
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),

    # Profile
    path('profile/', views.profile_view, name='profile'),
]
