from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

from .models import User


BOOTSTRAP_WIDGET_ATTRS = {'class': 'form-control'}


def apply_bootstrap(form):
    for field in form.fields.values():
        existing = field.widget.attrs.get('class', '')
        field.widget.attrs['class'] = (existing + ' form-control').strip()
    return form


class CustomerSignUpForm(UserCreationForm):
    """Registration form for customers."""

    email = forms.EmailField(required=True)
    phone_number = forms.CharField(max_length=15, required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'phone_number', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        apply_bootstrap(self)

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.Role.CUSTOMER
        user.email = self.cleaned_data['email']
        user.phone_number = self.cleaned_data['phone_number']
        if commit:
            user.save()
        return user


class SellerSignUpForm(UserCreationForm):
    """
    Registration form for small sellers.
    Sellers start as unverified (is_verified=False) until an admin approves
    them — see Step 2 / Step 9 for the verification workflow.
    """

    email = forms.EmailField(required=True)
    phone_number = forms.CharField(max_length=15, required=True)
    city = forms.CharField(max_length=100, required=True)
    state = forms.CharField(max_length=100, required=True)

    class Meta:
        model = User
        fields = (
            'username', 'email', 'phone_number',
            'city', 'state', 'password1', 'password2',
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        apply_bootstrap(self)

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.Role.SELLER
        user.email = self.cleaned_data['email']
        user.phone_number = self.cleaned_data['phone_number']
        user.city = self.cleaned_data['city']
        user.state = self.cleaned_data['state']
        user.is_verified = False  # must be verified by admin before selling
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = (
            'first_name', 'last_name', 'email', 'phone_number',
            'profile_picture', 'address', 'city', 'state', 'pincode',
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        apply_bootstrap(self)

    def clean_email(self):
        email = self.cleaned_data['email']
        qs = User.objects.filter(email=email).exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError('This email is already in use.')
        return email
