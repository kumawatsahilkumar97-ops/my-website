from django.contrib import admin
from .models import Review, Report


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('seller', 'customer', 'rating', 'created_at')
    list_filter = ('rating',)


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ('reason', 'seller', 'product', 'reporter', 'status', 'created_at')
    list_filter = ('status', 'reason')
    search_fields = ('seller__shop_name', 'product__name', 'reporter__username')
