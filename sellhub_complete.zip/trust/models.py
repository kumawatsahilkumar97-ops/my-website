from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models


class Review(models.Model):
    """
    A customer's review of a seller, tied to a completed order so only
    verified purchasers can leave feedback.
    """
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reviews_written')
    seller = models.ForeignKey('sellers.SellerProfile', on_delete=models.CASCADE, related_name='reviews')
    order = models.OneToOneField('orders.Order', on_delete=models.CASCADE, related_name='review')
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.rating}★ review of {self.seller.shop_name} by {self.customer.username}'


class Report(models.Model):
    """
    A trust/safety report filed by any user against a seller or product —
    reviewed and actioned by admins.
    """
    class Reason(models.TextChoices):
        FRAUD = 'FRAUD', 'Suspected fraud / scam'
        FAKE_LISTING = 'FAKE_LISTING', 'Fake or misleading listing'
        POOR_QUALITY = 'POOR_QUALITY', 'Poor product quality'
        INAPPROPRIATE = 'INAPPROPRIATE', 'Inappropriate content'
        OTHER = 'OTHER', 'Other'

    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open'
        REVIEWING = 'REVIEWING', 'Under Review'
        RESOLVED = 'RESOLVED', 'Resolved'
        DISMISSED = 'DISMISSED', 'Dismissed'

    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reports_filed')
    seller = models.ForeignKey('sellers.SellerProfile', on_delete=models.CASCADE, null=True, blank=True, related_name='reports')
    product = models.ForeignKey('products.Product', on_delete=models.CASCADE, null=True, blank=True, related_name='reports')
    reason = models.CharField(max_length=20, choices=Reason.choices)
    description = models.TextField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    admin_notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        target = self.seller.shop_name if self.seller else (self.product.name if self.product else 'Unknown')
        return f'Report on {target} — {self.get_reason_display()}'
