from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Avg, Count, Sum
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone

from accounts.models import User
from orders.models import Order
from products.models import Product
from sellers.models import SellerProfile
from .forms import ReviewForm, ReportForm
from .models import Review, Report


@login_required
def leave_review(request, order_id):
    order = get_object_or_404(Order, pk=order_id, customer=request.user)
    if order.status != Order.Status.DELIVERED:
        messages.error(request, 'You can only review orders that have been delivered.')
        return redirect('orders:order_detail', order_number=order.order_number)

    existing = getattr(order, 'review', None)
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=existing)
        if form.is_valid():
            review = form.save(commit=False)
            review.order = order
            review.customer = request.user
            review.seller = order.seller
            review.save()
            messages.success(request, 'Thanks for your review!')
            return redirect('orders:order_detail', order_number=order.order_number)
    else:
        form = ReviewForm(instance=existing)

    return render(request, 'trust/review_form.html', {'form': form, 'order': order})


def seller_reviews(request, slug):
    profile = get_object_or_404(SellerProfile, shop_slug=slug)
    reviews = profile.reviews.select_related('customer')
    avg_rating = reviews.aggregate(avg=Avg('rating'))['avg']
    return render(request, 'trust/seller_reviews.html', {
        'profile': profile, 'reviews': reviews, 'avg_rating': avg_rating,
    })


@login_required
def file_report(request):
    seller_id = request.GET.get('seller')
    product_id = request.GET.get('product')

    if request.method == 'POST':
        form = ReportForm(request.POST)
        if form.is_valid():
            report = form.save(commit=False)
            report.reporter = request.user
            if seller_id:
                report.seller = get_object_or_404(SellerProfile, pk=seller_id)
            if product_id:
                report.product = get_object_or_404(Product, pk=product_id)
            report.save()
            messages.success(request, 'Your report has been submitted. Our team will review it.')
            return redirect('accounts:home')
    else:
        form = ReportForm()

    return render(request, 'trust/report_form.html', {'form': form})


def _require_admin(user):
    if not user.is_authenticated or not getattr(user, 'is_admin_role', False):
        raise PermissionDenied('Admins only.')


@login_required
def admin_overview(request):
    """Richer admin dashboard: platform-wide stats + pending review queues."""
    _require_admin(request.user)

    stats = {
        'total_customers': User.objects.filter(role=User.Role.CUSTOMER).count(),
        'total_sellers': User.objects.filter(role=User.Role.SELLER).count(),
        'pending_sellers': SellerProfile.objects.filter(verification_status='PENDING').count(),
        'total_products': Product.objects.count(),
        'total_orders': Order.objects.count(),
        'total_revenue': Order.objects.exclude(status=Order.Status.CANCELLED).aggregate(s=Sum('total_amount'))['s'] or 0,
        'open_reports': Report.objects.filter(status=Report.Status.OPEN).count(),
    }

    pending_sellers = SellerProfile.objects.filter(verification_status='PENDING').order_by('-created_at')[:10]
    open_reports = Report.objects.filter(status=Report.Status.OPEN).select_related('seller', 'product', 'reporter')[:10]

    return render(request, 'trust/admin_overview.html', {
        'stats': stats, 'pending_sellers': pending_sellers, 'open_reports': open_reports,
    })


@login_required
def admin_report_detail(request, pk):
    _require_admin(request.user)
    report = get_object_or_404(Report, pk=pk)

    if request.method == 'POST':
        new_status = request.POST.get('status')
        notes = request.POST.get('admin_notes', '')
        if new_status in dict(Report.Status.choices):
            report.status = new_status
            report.admin_notes = notes
            if new_status in (Report.Status.RESOLVED, Report.Status.DISMISSED):
                report.resolved_at = timezone.now()
            report.save()
            messages.success(request, 'Report updated.')
            return redirect('trust:admin_overview')

    return render(request, 'trust/admin_report_detail.html', {'report': report})
