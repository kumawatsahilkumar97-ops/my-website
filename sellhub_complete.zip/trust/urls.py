from django.urls import path

from . import views

app_name = 'trust'

urlpatterns = [
    path('order/<int:order_id>/review/', views.leave_review, name='leave_review'),
    path('shop/<slug:slug>/reviews/', views.seller_reviews, name='seller_reviews'),
    path('report/', views.file_report, name='file_report'),

    path('admin-panel/overview/', views.admin_overview, name='admin_overview'),
    path('admin-panel/reports/<int:pk>/', views.admin_report_detail, name='admin_report_detail'),
]
