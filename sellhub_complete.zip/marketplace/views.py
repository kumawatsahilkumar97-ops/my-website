from django.db.models import Q, Min, Max
from django.shortcuts import render

from products.models import Product, Category


def search(request):
    """
    Customer-facing marketplace search & browse page.
    Filters: text query, category, city, price range, in-stock only.
    """
    products = Product.objects.filter(
        is_active=True,
        seller__is_active=True,
        seller__verification_status='APPROVED',
        seller__user__is_verified=True,
    ).select_related('seller', 'category').prefetch_related('images', 'varieties')

    query = request.GET.get('q', '').strip()
    category_id = request.GET.get('category', '')
    city = request.GET.get('city', '').strip()
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    sort = request.GET.get('sort', 'newest')

    if query:
        products = products.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query) |
            Q(seller__shop_name__icontains=query)
        )
    if category_id:
        products = products.filter(category_id=category_id)
    if city:
        products = products.filter(seller__city__icontains=city)
    if min_price:
        products = products.filter(base_price__gte=min_price)
    if max_price:
        products = products.filter(base_price__lte=max_price)

    if sort == 'price_low':
        products = products.order_by('base_price')
    elif sort == 'price_high':
        products = products.order_by('-base_price')
    else:
        products = products.order_by('-created_at')

    categories = Category.objects.filter(is_active=True, parent__isnull=True)

    return render(request, 'marketplace/search.html', {
        'products': products.distinct(),
        'categories': categories,
        'query': query,
        'selected_category': category_id,
        'city': city,
        'min_price': min_price,
        'max_price': max_price,
        'sort': sort,
    })
