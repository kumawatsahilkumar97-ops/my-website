from django import forms
from django.forms import inlineformset_factory

from .models import Product, ProductVariety, ProductImage


def _bootstrapify(form):
    for name, field in form.fields.items():
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = 'form-check-input'
        else:
            existing = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = (existing + ' form-control').strip()
    return form


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            'category', 'name', 'description', 'unit',
            'base_price', 'is_customizable', 'is_active',
        ]
        widgets = {'description': forms.Textarea(attrs={'rows': 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


class ProductVarietyForm(forms.ModelForm):
    class Meta:
        model = ProductVariety
        fields = ['name', 'sku', 'price', 'stock_quantity', 'is_active']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


ProductVarietyFormSet = inlineformset_factory(
    Product, ProductVariety,
    form=ProductVarietyForm,
    extra=1, can_delete=True,
)


class ProductImageForm(forms.ModelForm):
    class Meta:
        model = ProductImage
        fields = ['image', 'is_primary', 'alt_text']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


ProductImageFormSet = inlineformset_factory(
    Product, ProductImage,
    form=ProductImageForm,
    extra=2, can_delete=True,
)
