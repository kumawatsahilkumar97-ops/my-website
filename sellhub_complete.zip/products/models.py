from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Category(models.Model):
    """
    Product category. Supports optional subcategories via self-referencing FK
    (e.g. "Textiles" -> "Sarees", "Handicrafts" -> "Pottery").
    """
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=110, unique=True, blank=True)
    parent = models.ForeignKey(
        'self', on_delete=models.CASCADE, null=True, blank=True,
        related_name='subcategories',
    )
    icon = models.ImageField(upload_to='category_icons/', blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def __str__(self):
        if self.parent:
            return f'{self.parent.name} > {self.name}'
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Product(models.Model):
    """A product listed by a seller. Actual sellable units/prices live on
    ProductVariety (Step 3) so one product can have several options
    (e.g. sizes, weights, colors) — batches/origin tracking comes in Step 4."""

    class Unit(models.TextChoices):
        PIECE = 'PIECE', 'Piece'
        KG = 'KG', 'Kilogram'
        GRAM = 'GRAM', 'Gram'
        LITRE = 'LITRE', 'Litre'
        DOZEN = 'DOZEN', 'Dozen'
        PACK = 'PACK', 'Pack'
        METER = 'METER', 'Meter'

    seller = models.ForeignKey(
        'sellers.SellerProfile', on_delete=models.CASCADE, related_name='products',
    )
    category = models.ForeignKey(
        Category, on_delete=models.SET_NULL, null=True, related_name='products',
    )
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, blank=True)
    description = models.TextField(blank=True)
    unit = models.CharField(max_length=10, choices=Unit.choices, default=Unit.PIECE)

    base_price = models.DecimalField(
        max_digits=10, decimal_places=2,
        help_text='Default/starting price. Individual varieties can override this.',
    )

    is_customizable = models.BooleanField(
        default=False,
        help_text='Allow customers to request custom versions of this product (Step 7).',
    )
    is_active = models.BooleanField(
        default=True, help_text='Uncheck to temporarily hide this product without deleting it.',
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        unique_together = [('seller', 'slug')]

    def __str__(self):
        return f'{self.name} ({self.seller.shop_name})'

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while Product.objects.filter(seller=self.seller, slug=slug).exclude(pk=self.pk).exists():
                slug = f'{base_slug}-{counter}'
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('products:product_detail', kwargs={
            'shop_slug': self.seller.shop_slug, 'product_slug': self.slug,
        })

    @property
    def is_live(self):
        return self.is_active and self.seller.is_live

    @property
    def primary_image(self):
        return self.images.filter(is_primary=True).first() or self.images.first()

    @property
    def price_range(self):
        """Returns (min_price, max_price) across varieties, or (base_price, base_price) if none."""
        prices = list(self.varieties.filter(is_active=True).values_list('price', flat=True))
        if not prices:
            return self.base_price, self.base_price
        return min(prices), max(prices)


class ProductVariety(models.Model):
    """
    A specific sellable option of a product — e.g. "500g pack", "Red - Large",
    "Small clay pot". Each variety has its own price and stock.
    """
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='varieties')
    name = models.CharField(
        max_length=100,
        help_text='e.g. "500g", "Red - Medium", "Set of 6"',
    )
    sku = models.CharField(max_length=64, blank=True, help_text='Optional internal stock code.')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Product varieties'
        ordering = ['price']

    def __str__(self):
        return f'{self.product.name} — {self.name}'

    @property
    def in_stock(self):
        return self.is_active and self.stock_quantity > 0


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='product_images/')
    is_primary = models.BooleanField(default=False)
    alt_text = models.CharField(max_length=150, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-is_primary', 'uploaded_at']

    def __str__(self):
        return f'Image for {self.product.name}'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.is_primary:
            # Ensure only one primary image per product
            ProductImage.objects.filter(product=self.product).exclude(pk=self.pk).update(is_primary=False)
