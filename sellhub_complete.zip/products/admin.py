from django.contrib import admin

from .models import Category, Product, ProductVariety, ProductImage


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}


class ProductVarietyInline(admin.TabularInline):
    model = ProductVariety
    extra = 1


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'seller', 'category', 'base_price', 'is_active', 'created_at')
    list_filter = ('is_active', 'is_customizable', 'category')
    search_fields = ('name', 'seller__shop_name')
    inlines = [ProductVarietyInline, ProductImageInline]
