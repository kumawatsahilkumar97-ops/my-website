from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404

from sellers.models import SellerProfile
from .forms import ProductForm, ProductVarietyFormSet, ProductImageFormSet
from .models import Product, Category


def _get_own_seller_profile(user):
    if not user.is_authenticated or not user.is_seller:
        raise PermissionDenied('Only sellers can manage products.')
    profile = SellerProfile.objects.filter(user=user).first()
    if profile is None:
        return None
    return profile


@login_required
def product_list(request):
    """Seller's own product management list."""
    profile = _get_own_seller_profile(request.user)
    if profile is None:
        messages.info(request, 'Set up your shop profile first before adding products.')
        return redirect('sellers:shop_setup')

    products = profile.products.all().select_related('category').prefetch_related('images', 'varieties')
    return render(request, 'products/product_list.html', {'products': products, 'profile': profile})


@login_required
def product_create(request):
    profile = _get_own_seller_profile(request.user)
    if profile is None:
        messages.info(request, 'Set up your shop profile first before adding products.')
        return redirect('sellers:shop_setup')

    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.seller = profile
            product.save()

            variety_formset = ProductVarietyFormSet(request.POST, instance=product)
            image_formset = ProductImageFormSet(request.POST, request.FILES, instance=product)
            if variety_formset.is_valid() and image_formset.is_valid():
                variety_formset.save()
                image_formset.save()
                messages.success(request, f'"{product.name}" was created.')
                return redirect('products:product_list')
            else:
                messages.error(request, 'Please fix the errors in varieties/images below.')
        else:
            variety_formset = ProductVarietyFormSet(request.POST)
            image_formset = ProductImageFormSet(request.POST, request.FILES)
    else:
        form = ProductForm()
        variety_formset = ProductVarietyFormSet()
        image_formset = ProductImageFormSet()

    return render(request, 'products/product_form.html', {
        'form': form, 'variety_formset': variety_formset, 'image_formset': image_formset,
        'is_new': True,
    })


@login_required
def product_edit(request, pk):
    profile = _get_own_seller_profile(request.user)
    if profile is None:
        raise PermissionDenied
    product = get_object_or_404(Product, pk=pk, seller=profile)

    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        variety_formset = ProductVarietyFormSet(request.POST, instance=product)
        image_formset = ProductImageFormSet(request.POST, request.FILES, instance=product)
        if form.is_valid() and variety_formset.is_valid() and image_formset.is_valid():
            form.save()
            variety_formset.save()
            image_formset.save()
            messages.success(request, f'"{product.name}" was updated.')
            return redirect('products:product_list')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = ProductForm(instance=product)
        variety_formset = ProductVarietyFormSet(instance=product)
        image_formset = ProductImageFormSet(instance=product)

    return render(request, 'products/product_form.html', {
        'form': form, 'variety_formset': variety_formset, 'image_formset': image_formset,
        'is_new': False, 'product': product,
    })


@login_required
def product_delete(request, pk):
    profile = _get_own_seller_profile(request.user)
    if profile is None:
        raise PermissionDenied
    product = get_object_or_404(Product, pk=pk, seller=profile)
    if request.method == 'POST':
        name = product.name
        product.delete()
        messages.success(request, f'"{name}" was deleted.')
        return redirect('products:product_list')
    return render(request, 'products/product_confirm_delete.html', {'product': product})


def product_detail(request, shop_slug, product_slug):
    """Public product detail page."""
    product = get_object_or_404(
        Product.objects.select_related('seller', 'category').prefetch_related('images', 'varieties'),
        seller__shop_slug=shop_slug, slug=product_slug,
    )
    is_owner = request.user.is_authenticated and getattr(request.user, 'seller_profile', None) == product.seller
    if not product.is_live and not is_owner:
        raise PermissionDenied('This product is not currently available.')

    return render(request, 'products/product_detail.html', {
        'product': product, 'is_owner': is_owner,
        'varieties': product.varieties.filter(is_active=True),
    })


def category_list(request):
    categories = Category.objects.filter(is_active=True, parent__isnull=True).prefetch_related('subcategories')
    return render(request, 'products/category_list.html', {'categories': categories})
