from django.urls import path

from . import views

app_name = 'products'

urlpatterns = [
    path('my-products/', views.product_list, name='product_list'),
    path('my-products/add/', views.product_create, name='product_create'),
    path('my-products/<int:pk>/edit/', views.product_edit, name='product_edit'),
    path('my-products/<int:pk>/delete/', views.product_delete, name='product_delete'),
    path('categories/', views.category_list, name='category_list'),
    path('shop/<slug:shop_slug>/product/<slug:product_slug>/', views.product_detail, name='product_detail'),
]
