from django.urls import path

from . import views

app_name = 'requests_app'

urlpatterns = [
    # Step 7: Customization
    path('customize/product/<int:product_id>/', views.customization_create, name='customization_create'),
    path('customize/my-requests/', views.customization_my_list, name='customization_my_list'),
    path('customize/my-requests/<int:pk>/respond/', views.customization_respond, name='customization_respond'),
    path('customize/seller/requests/', views.customization_seller_list, name='customization_seller_list'),
    path('customize/seller/requests/<int:pk>/quote/', views.customization_quote, name='customization_quote'),

    # Step 8: Demand System
    path('demand/new/', views.demand_create, name='demand_create'),
    path('demand/browse/', views.demand_browse, name='demand_browse'),
    path('demand/my-requests/', views.demand_my_list, name='demand_my_list'),
    path('demand/<int:pk>/', views.demand_detail, name='demand_detail'),
    path('demand/<int:pk>/quote/', views.demand_submit_quote, name='demand_submit_quote'),
    path('demand/<int:pk>/quote/<int:quote_id>/accept/', views.demand_accept_quote, name='demand_accept_quote'),
]
