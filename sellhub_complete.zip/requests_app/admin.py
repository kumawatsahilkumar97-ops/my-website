from django.contrib import admin
from .models import CustomizationRequest, CustomizationQuotation, DemandRequest, DemandQuotation


@admin.register(CustomizationRequest)
class CustomizationRequestAdmin(admin.ModelAdmin):
    list_display = ('product', 'customer', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('product__name', 'customer__username')


admin.site.register(CustomizationQuotation)


@admin.register(DemandRequest)
class DemandRequestAdmin(admin.ModelAdmin):
    list_display = ('title', 'customer', 'status', 'city', 'created_at')
    list_filter = ('status',)
    search_fields = ('title', 'customer__username', 'city')


@admin.register(DemandQuotation)
class DemandQuotationAdmin(admin.ModelAdmin):
    list_display = ('demand_request', 'seller', 'price', 'status', 'created_at')
    list_filter = ('status',)
