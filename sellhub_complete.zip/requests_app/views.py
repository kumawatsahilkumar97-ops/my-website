from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404

from products.models import Product
from sellers.models import SellerProfile
from .forms import (
    CustomizationRequestForm, CustomizationQuotationForm,
    DemandRequestForm, DemandQuotationForm,
)
from .models import CustomizationRequest, CustomizationQuotation, DemandRequest, DemandQuotation


# --- Step 7: Customization ------------------------------------------------

@login_required
def customization_create(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_customizable=True, is_active=True)
    if not request.user.is_customer:
        raise PermissionDenied('Only customers can request customizations.')

    if request.method == 'POST':
        form = CustomizationRequestForm(request.POST, request.FILES)
        if form.is_valid():
            req = form.save(commit=False)
            req.customer = request.user
            req.product = product
            req.save()
            messages.success(request, 'Your customization request was sent to the seller.')
            return redirect('requests_app:customization_my_list')
    else:
        form = CustomizationRequestForm()

    return render(request, 'requests_app/customization_form.html', {'form': form, 'product': product})


@login_required
def customization_my_list(request):
    reqs = request.user.customization_requests.select_related('product').all()
    return render(request, 'requests_app/customization_my_list.html', {'requests': reqs})


@login_required
def customization_seller_list(request):
    profile = getattr(request.user, 'seller_profile', None)
    if profile is None:
        raise PermissionDenied
    reqs = CustomizationRequest.objects.filter(product__seller=profile).select_related('product', 'customer')
    return render(request, 'requests_app/customization_seller_list.html', {'requests': reqs})


@login_required
def customization_quote(request, pk):
    profile = getattr(request.user, 'seller_profile', None)
    req = get_object_or_404(CustomizationRequest, pk=pk, product__seller=profile)

    existing = getattr(req, 'quotation', None)
    if request.method == 'POST':
        form = CustomizationQuotationForm(request.POST, instance=existing)
        if form.is_valid():
            quote = form.save(commit=False)
            quote.request = req
            quote.save()
            req.status = CustomizationRequest.Status.QUOTED
            req.save(update_fields=['status'])
            messages.success(request, 'Quotation sent to customer.')
            return redirect('requests_app:customization_seller_list')
    else:
        form = CustomizationQuotationForm(instance=existing)

    return render(request, 'requests_app/customization_quote_form.html', {'form': form, 'req': req})


@login_required
def customization_respond(request, pk):
    """Customer accepts or rejects a seller's quotation."""
    req = get_object_or_404(CustomizationRequest, pk=pk, customer=request.user)
    action = request.POST.get('action')
    if action == 'accept':
        req.status = CustomizationRequest.Status.ACCEPTED
    elif action == 'cancel':
        req.status = CustomizationRequest.Status.CANCELLED
    req.save(update_fields=['status'])
    messages.success(request, f'Request marked as {req.get_status_display()}.')
    return redirect('requests_app:customization_my_list')


# --- Step 8: Demand System -------------------------------------------------

@login_required
def demand_create(request):
    if not request.user.is_customer:
        raise PermissionDenied('Only customers can post demand requests.')

    if request.method == 'POST':
        form = DemandRequestForm(request.POST)
        if form.is_valid():
            demand = form.save(commit=False)
            demand.customer = request.user
            demand.save()
            messages.success(request, 'Your request is live! Sellers can now submit quotes.')
            return redirect('requests_app:demand_my_list')
    else:
        form = DemandRequestForm()

    return render(request, 'requests_app/demand_form.html', {'form': form})


def demand_browse(request):
    """Public board of open demand requests — sellers browse to find quoting opportunities."""
    demands = DemandRequest.objects.filter(status=DemandRequest.Status.OPEN).select_related('category', 'customer')
    return render(request, 'requests_app/demand_browse.html', {'demands': demands})


@login_required
def demand_my_list(request):
    demands = request.user.demand_requests.prefetch_related('quotations__seller')
    return render(request, 'requests_app/demand_my_list.html', {'demands': demands})


@login_required
def demand_detail(request, pk):
    demand = get_object_or_404(DemandRequest, pk=pk)
    is_owner = demand.customer == request.user
    quotations = demand.quotations.select_related('seller') if is_owner else []
    seller_profile = getattr(request.user, 'seller_profile', None)
    my_quote = None
    if seller_profile:
        my_quote = demand.quotations.filter(seller=seller_profile).first()

    return render(request, 'requests_app/demand_detail.html', {
        'demand': demand, 'is_owner': is_owner, 'quotations': quotations,
        'seller_profile': seller_profile, 'my_quote': my_quote,
    })


@login_required
def demand_submit_quote(request, pk):
    profile = getattr(request.user, 'seller_profile', None)
    if profile is None:
        raise PermissionDenied('Only sellers can submit quotes.')
    demand = get_object_or_404(DemandRequest, pk=pk, status=DemandRequest.Status.OPEN)

    existing = demand.quotations.filter(seller=profile).first()
    if request.method == 'POST':
        form = DemandQuotationForm(request.POST, instance=existing)
        if form.is_valid():
            quote = form.save(commit=False)
            quote.demand_request = demand
            quote.seller = profile
            quote.save()
            messages.success(request, 'Your quote was submitted.')
            return redirect('requests_app:demand_detail', pk=demand.pk)
    else:
        form = DemandQuotationForm(instance=existing)

    return render(request, 'requests_app/demand_quote_form.html', {'form': form, 'demand': demand})


@login_required
def demand_accept_quote(request, pk, quote_id):
    demand = get_object_or_404(DemandRequest, pk=pk, customer=request.user)
    quote = get_object_or_404(DemandQuotation, pk=quote_id, demand_request=demand)

    quote.status = DemandQuotation.Status.ACCEPTED
    quote.save(update_fields=['status'])
    demand.quotations.exclude(pk=quote.pk).update(status=DemandQuotation.Status.REJECTED)
    demand.status = DemandRequest.Status.CLOSED
    demand.save(update_fields=['status'])

    messages.success(request, f'Quote from {quote.seller.shop_name} accepted! Coordinate directly to finalize the order.')
    return redirect('requests_app:demand_detail', pk=demand.pk)
