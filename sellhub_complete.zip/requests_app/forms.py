from django import forms

from .models import CustomizationRequest, CustomizationQuotation, DemandRequest, DemandQuotation


def _bootstrapify(form):
    for field in form.fields.values():
        existing = field.widget.attrs.get('class', '')
        field.widget.attrs['class'] = (existing + ' form-control').strip()
    return form


class CustomizationRequestForm(forms.ModelForm):
    class Meta:
        model = CustomizationRequest
        fields = ['details', 'desired_quantity', 'reference_image']
        widgets = {'details': forms.Textarea(attrs={'rows': 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


class CustomizationQuotationForm(forms.ModelForm):
    class Meta:
        model = CustomizationQuotation
        fields = ['price', 'estimated_days', 'message']
        widgets = {'message': forms.Textarea(attrs={'rows': 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


class DemandRequestForm(forms.ModelForm):
    class Meta:
        model = DemandRequest
        fields = ['category', 'title', 'description', 'desired_quantity', 'city', 'budget_min', 'budget_max']
        widgets = {'description': forms.Textarea(attrs={'rows': 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)


class DemandQuotationForm(forms.ModelForm):
    class Meta:
        model = DemandQuotation
        fields = ['price', 'estimated_days', 'message']
        widgets = {'message': forms.Textarea(attrs={'rows': 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bootstrapify(self)
