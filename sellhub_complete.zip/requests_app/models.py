from django.conf import settings
from django.db import models


# ---------------------------------------------------------------------------
# Step 7: Customization — customer asks a specific seller to customize one
# of their existing products (e.g. "can you make this pot in blue?").
# ---------------------------------------------------------------------------

class CustomizationRequest(models.Model):
    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Awaiting Quotation'
        QUOTED = 'QUOTED', 'Quoted'
        ACCEPTED = 'ACCEPTED', 'Accepted'
        REJECTED = 'REJECTED', 'Rejected by Seller'
        CANCELLED = 'CANCELLED', 'Cancelled by Customer'
        COMPLETED = 'COMPLETED', 'Completed'

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='customization_requests')
    product = models.ForeignKey('products.Product', on_delete=models.CASCADE, related_name='customization_requests')
    details = models.TextField(help_text='Describe the customization you want.')
    desired_quantity = models.PositiveIntegerField(default=1)
    reference_image = models.ImageField(upload_to='customization_refs/', blank=True, null=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Customization request for {self.product.name} by {self.customer.username}'


class CustomizationQuotation(models.Model):
    request = models.OneToOneField(CustomizationRequest, on_delete=models.CASCADE, related_name='quotation')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    estimated_days = models.PositiveIntegerField(help_text='Estimated turnaround time in days.')
    message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Quote ₹{self.price} for {self.request}'


# ---------------------------------------------------------------------------
# Step 8: Demand System — customer posts an open "Request a Product" that
# isn't tied to any specific seller/product; any interested seller can quote.
# ---------------------------------------------------------------------------

class DemandRequest(models.Model):
    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open for Quotes'
        CLOSED = 'CLOSED', 'Closed'
        CANCELLED = 'CANCELLED', 'Cancelled'

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='demand_requests')
    category = models.ForeignKey('products.Category', on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=150)
    description = models.TextField()
    desired_quantity = models.PositiveIntegerField(default=1)
    city = models.CharField(max_length=100, blank=True, help_text='Optional: prefer sellers near this city.')
    budget_min = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    budget_max = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title


class DemandQuotation(models.Model):
    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Pending'
        ACCEPTED = 'ACCEPTED', 'Accepted'
        REJECTED = 'REJECTED', 'Rejected'

    demand_request = models.ForeignKey(DemandRequest, on_delete=models.CASCADE, related_name='quotations')
    seller = models.ForeignKey('sellers.SellerProfile', on_delete=models.CASCADE, related_name='demand_quotations')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    message = models.TextField(blank=True)
    estimated_days = models.PositiveIntegerField(help_text='Estimated turnaround time in days.')
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [('demand_request', 'seller')]
        ordering = ['price']

    def __str__(self):
        return f'{self.seller.shop_name} quoted ₹{self.price} for "{self.demand_request.title}"'
