from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('accounts.urls')),
    path('', include('sellers.urls')),
    path('', include('products.urls')),
    path('', include('traceability.urls')),
    path('', include('marketplace.urls')),
    path('', include('orders.urls')),
    path('', include('requests_app.urls')),
    path('', include('trust.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
